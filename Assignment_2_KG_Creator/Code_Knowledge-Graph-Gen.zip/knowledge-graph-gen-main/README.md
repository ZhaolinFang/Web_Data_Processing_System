# knowledge-graph-gen
WDPS 2021 | Assignment 2 | Group 17 | Knowledge Graph generator based on raw text


